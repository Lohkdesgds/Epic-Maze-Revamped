#include "display_event.h"

namespace LSW {

	namespace EpicMazeR {

		displayer_data displayer::data;
		event_mng_data event_mng::data;



		const bool displayer::think()
		{
			fixLoad();
			event_mng evmng_e;
			int level = 0;
			while (data.now != LSW_S_EXIT)
			{
				data.lastC = GetTickCount64();
				double multiply = 1.0;

				switch (data.now)
				{
				case LSW_S_INITIALIZING:
				{
					/* Imagens||fontes a serem usadas: */
					ALLEGRO_BITMAP *log;
					ALLEGRO_FONT *font;

					log = data.data_control.get(LSW_BMP_LOGO);
					font = data.data_control.get(LSW_FONT_DEJAVUSANS);

					multiplier(); // reset last call
					clock_t now = clock()-CLOCKS_PER_SEC/4;
					//clock_t lastload = clock() - CLOCKS_PER_SEC / 10;
					double nowFps = 0.0;
					float posoffset = 1.0f;
					bool addin = true;
					bool loaded_all = false;
					int ref_loading_files = 0;
					short counter_times = 0;

					std::thread thr_local(_thr_temp_loadallresources, &ref_loading_files, &loaded_all);

					while (counter_times < 3 || !loaded_all)
					{
						int key = evmng_e.getLastKeyIfAvailable();

						if (key >= 0) counter_times = 99;

						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
						}
						if (addin) posoffset += multiply * 0.03 * posoffset + ((posoffset > 0) ? 0.01 : -0.01);
						else posoffset -= multiply * 0.03 * posoffset - ((posoffset < 0) ? 0.01 : -0.01);
						if (fabsf(posoffset) > 40.0) {
							if (posoffset < 0.0) posoffset = -40.0;
							else posoffset = 40.0;
							addin = !addin;
						}
						if (!addin && fabsf(posoffset) < 0.12) {
							posoffset = -posoffset;
							addin = !addin;
							counter_times++;
						}

						clearTo(al_map_rgb(0, 0, 0));
						drawIt(log, 0.0, -0.4, 0);

						float a, b;
						a = data.usedx*(830 + 1.2*posoffset) / base_res[0];
						b = data.usedy*650.0 / base_res[1];
						al_draw_textf(font, al_map_rgb(255, 255, 255), a, b , 0, "Loading... (%02.1f%c)",(99.9f*ref_loading_files/LSW_BMP_MAX),'%');
						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f ~ %.3fx%.3f [%.3f][%d]", (float)nowFps, a, b, posoffset, counter_times);

						flip();

						//al_rest(0.016);
						multiply = multiplier();

						/*if (clock() - lastload > CLOCKS_PER_SEC / 10) {
							lastload += CLOCKS_PER_SEC / 10;
							if (++ref_loading_files < LSW_BMP_MAX)
							{
								data.data_control.load((images_available)ref_loading_files);
							}
							else {
								loaded_all = true;
								ref_loading_files = LSW_BMP_MAX;
							}
						}*/
					}

					thr_local.join();

					//data.data_control.loadAll();
					//multiplier();

					for (double to_add = 0.0; to_add < 90.0 && counter_times != 99; to_add += multiplier()){
						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
						}

						clearTo(al_map_rgb(0, 0, 0));
						drawIt(log, 0.0, -0.4, 0);

						float a, b;
						a = data.usedx*830.0 / base_res[0];
						b = data.usedy*(650.0 + to_add*0.4) / base_res[1];
						al_draw_textf(font, al_map_rgb(255 * (1.0 - to_add / 90.0), 255 * (1.0 - to_add / 90.0), 255 * (1.0 - to_add / 90.0)), a, b, 0, "Loading...");
						if (to_add > 45.0)al_draw_textf(font, al_map_rgb(255 * ((to_add-45.0) / 45.0), 255 * ((to_add - 45.0) / 45.0), 255 * ((to_add - 45.0) / 45.0)), a, b, 0, "   DONE   ");
						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f ~ %.3fx%.3f [%.3f][%d]", (float)nowFps, a, b, posoffset, counter_times);

						flip();
					}

					data.now = LSW_S_MENU;
				}
					break;
				case LSW_S_MENU:
				{
					ALLEGRO_BITMAP *log, *vig, *opt_01, *opt_02, *opt_03, *opt_04;
					ALLEGRO_FONT *font;
					clock_t now = clock() - CLOCKS_PER_SEC / 4;
					double nowFps = 0.0, nowMult = multiply;
					int opt = 0;
					bool choosing = true;

					log = data.data_control.get(LSW_BMP_LOGO);
					vig = data.data_control.get(LSW_BMP_VIGNETTE);
					opt_01 = data.data_control.get(LSW_BMP_MENU_OPT_01);
					opt_02 = data.data_control.get(LSW_BMP_MENU_OPT_02);
					opt_03 = data.data_control.get(LSW_BMP_MENU_OPT_03);
					opt_04 = data.data_control.get(LSW_BMP_MENU_OPT_04);
					font = data.data_control.get(LSW_FONT_DEJAVUSANS);

					multiplier(); // reset for animation
					multiply = 0.0;

					// pre-animation full of features because I CAN :3
					for (double pos = -1.55; pos < -0.02; pos += multiply*(0.2*fabsf(pos/2.0)))
					{
						int key = evmng_e.getLastKeyIfAvailable();

						switch (key)
						{
						case ALLEGRO_KEY_UP:
							if (--opt < 0) opt = 3;
							break;
						case ALLEGRO_KEY_DOWN:
							if (++opt > 3) opt = 0;
							break;
						}

						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
							nowMult = multiply;
						}

						clearTo(al_map_rgb(0, 0, 0));
						bganim(multiply);
						drawIt(log, -(pos + 0.02), -0.5, 0);

						switch (opt)
						{
						case 0:
							drawIt(opt_01, pos + 0.02, 0.0, 0);
							break;
						case 1:
							drawIt(opt_02, pos + 0.02, 0.0, 0);
							break;
						case 2:
							drawIt(opt_03, pos + 0.02, 0.0, 0);
							break;
						case 3:
							drawIt(opt_04, pos + 0.02, 0.0, 0);
							break;
						default:
							opt = 0;
							break;
						}

						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f | TIMEMULTIPLY: %.3f | POSRN: %.4f", (float)nowFps, (float)nowMult, pos);
						drawIt(vig, 0.0, 0.0, 0);
						flip();

						multiply = multiplier();
					}

					while (choosing)
					{
						int key = evmng_e.getLastKeyIfAvailable();

						switch (key)
						{
						case ALLEGRO_KEY_UP:
							if (--opt < 0) opt = 3;
							break;
						case ALLEGRO_KEY_DOWN:
							if (++opt > 3) opt = 0;
							break;
						case ALLEGRO_KEY_ESCAPE:
							opt = 3;
							choosing = false;
							break;
						case ALLEGRO_KEY_ENTER:
							choosing = false;
							break;
						case ALLEGRO_KEY_1:
							opt = 0;
							choosing = false;
							break;
						case ALLEGRO_KEY_2:
							opt = 1;
							choosing = false;
							break;
						case ALLEGRO_KEY_3:
							opt = 2;
							choosing = false;
							break;
						case ALLEGRO_KEY_4:
							opt = 3;
							choosing = false;
							break;
						}

						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
							nowMult = multiply;
						}
						clearTo(al_map_rgb(0, 0, 0));
						bganim(multiply);
						drawIt(log, 0.0, -0.5, 0);

						switch (opt)
						{
						case 0:
							drawIt(opt_01, 0.0, 0.0, 0);
							break;
						case 1:
							drawIt(opt_02, 0.0, 0.0, 0);
							break;
						case 2:
							drawIt(opt_03, 0.0, 0.0, 0);
							break;
						case 3:
							drawIt(opt_04, 0.0, 0.0, 0);
							break;
						default:
							opt = 0;
							break;
						}

						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f | TIMEMULTIPLY: %.3f", (float)nowFps, (float)nowMult);
						drawIt(vig, 0.0, 0.0, 0);
						flip();
						multiply = multiplier();
					}

					for (double pos = 0.02; pos < 1.55; pos += multiply * (0.2*fabsf(pos / 2.0)))
					{
						clearTo(al_map_rgb(0, 0, 0));
						bganim(multiply);
						drawIt(log, -(pos - 0.02), -0.5, 0);

						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
							nowMult = multiply;
						}

						switch (opt)
						{
						case 0:
							drawIt(opt_01, pos - 0.02, 0.0, 0);
							break;
						case 1:
							drawIt(opt_02, pos - 0.02, 0.0, 0);
							break;
						case 2:
							drawIt(opt_03, pos - 0.02, 0.0, 0);
							break;
						case 3:
							drawIt(opt_04, pos - 0.02, 0.0, 0);
							break;
						default:
							opt = 0;
							break;
						}

						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f | TIMEMULTIPLY: %.3f | POSRN: %.4f", (float)nowFps, (float)nowMult, pos);
						drawIt(vig, 0.0, 0.0, 0);
						flip();

						multiply = multiplier();
					}

					switch (opt) {
					case 0:
						data.now = LSW_S_PLAY;
						break;
					case 1:
						data.now = LSW_S_INSTR;
						break;
					case 2:
						data.now = LSW_S_RECORDS;
						break;
					case 3:
						data.now = LSW_S_EXIT;
						break;
					}
				}
					break;
				case LSW_S_INSTR:
				{
					ALLEGRO_BITMAP *log, *vig, *instr;
					ALLEGRO_FONT *font;
					clock_t now = clock() - CLOCKS_PER_SEC / 4;
					double nowFps = 0.0, nowMult = multiply;
					bool choosing = true;

					log = data.data_control.get(LSW_BMP_LOGO);
					vig = data.data_control.get(LSW_BMP_VIGNETTE);
					instr = data.data_control.get(LSW_BMP_INSTR);
					font = data.data_control.get(LSW_FONT_DEJAVUSANS);

					multiplier(); // reset for animation
					multiply = 0.0;

					// pre-animation full of features because I CAN :3
					for (double pos = -1.55; pos < -0.02; pos += multiply * (0.2*fabsf(pos / 2.0)))
					{
						clearTo(al_map_rgb(0, 0, 0));
						bganim(multiply);
						drawIt(log, (pos + 0.02)*0.8, -0.5, 0);

						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
							nowMult = multiply;
						}

						drawIt(instr, pos + 0.02, 0.0, 0);

						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f | TIMEMULTIPLY: %.3f | POSRN: %.4f", (float)nowFps, (float)nowMult, pos);
						drawIt(vig, 0.0, 0.0, 0);
						flip();

						multiply = multiplier();
					}

					while (choosing)
					{
						int key = evmng_e.getLastKeyIfAvailable();

						if (key >= 0) choosing = false;

						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
							nowMult = multiply;
						}

						clearTo(al_map_rgb(0, 0, 0));
						bganim(multiply);
						drawIt(log, 0.0, -0.5, 0);
												
						drawIt(instr, 0.0, 0.0, 0);

						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f | TIMEMULTIPLY: %.3f", (float)nowFps, (float)nowMult);
						drawIt(vig, 0.0, 0.0, 0);
						flip();
						multiply = multiplier();
					}

					for (double pos = 0.02; pos < 1.55; pos += multiply * (0.2*fabsf(pos / 2.0)))
					{
						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
							nowMult = multiply;
						}

						clearTo(al_map_rgb(0, 0, 0));
						bganim(multiply);
						drawIt(log, (pos - 0.02)*0.8, -0.5, 0);
						
						drawIt(instr, pos - 0.02, 0.0, 0);

						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f | TIMEMULTIPLY: %.3f | POSRN: %.4f", (float)nowFps, (float)nowMult, pos);
						drawIt(vig, 0.0, 0.0, 0);
						flip();

						multiply = multiplier();
					}
					data.now = LSW_S_MENU;
				}
					break;
				case LSW_S_RECORDS:
				{
					ALLEGRO_BITMAP *log, *vig, *rec_back;
					ALLEGRO_FONT *font;
					FILE* fp = nullptr;
					clock_t now = clock() - CLOCKS_PER_SEC / 4;
					double nowFps = 0.0, nowMult = multiply;
					bool choosing = true;
					std::string records[10] = {
						"=-=-=-=-=-=-=-=-=-=-=-=",
						"=-=-=-=-=-=-=-=-=-=-=-=",
						"=-=-=-=-=-=-=-=-=-=-=-=",
						"=-=-=-=-=-=-=-=-=-=-=-=",
						"=-=-=-=-=-=-=-=-=-=-=-=",
						"=-=-=-=-=-=-=-=-=-=-=-=",
						"=-=-=-=-=-=-=-=-=-=-=-=",
						"=-=-=-=-=-=-=-=-=-=-=-=",
						"=-=-=-=-=-=-=-=-=-=-=-=",
						"=-=-=-=-=-=-=-=-=-=-=-="
					};

					if (fopen_s(&fp, "records.txt", "r") == 0)
					{
						for (int u = 0; u < 10 && !feof(fp); u++)
						{
							char line[128];
							fgets(line, 128, fp);
							records[u] = line;
							if (records[u].find('\n') != std::string::npos) records[u].pop_back();
						}
						fclose(fp);
					}

					log = data.data_control.get(LSW_BMP_LOGO);
					vig = data.data_control.get(LSW_BMP_VIGNETTE);
					rec_back = data.data_control.get(LSW_BMP_REC_BACK);
					font = data.data_control.get(LSW_FONT_DEJAVUSANS);

					multiplier(); // reset for animation
					multiply = 0.0;

					// pre-animation full of features because I CAN :3
					for (double pos = -1.55; pos < -0.02; pos += multiply * (0.2*fabsf(pos / 2.0)))
					{
						clearTo(al_map_rgb(0, 0, 0));
						bganim(multiply);
						drawIt(log, (pos + 0.02)*0.8, -0.5, 0);

						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
							nowMult = multiply;
						}

						drawIt(rec_back, pos + 0.02, 0.1, 0);

						int tempcount = 0;
						for (auto& i : records) {
							al_draw_textf(font, al_map_rgb(255, 255, 255), ((pos + 0.02) + 1.0)*0.5*data.usedx, (0.46 + tempcount * 0.038)*data.usedy, ALLEGRO_ALIGN_CENTER, "%s", i.c_str());
							tempcount++;
						}

						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f | TIMEMULTIPLY: %.3f | POSRN: %.4f", (float)nowFps, (float)nowMult, pos);
						drawIt(vig, 0.0, 0.0, 0);
						flip();

						multiply = multiplier();
					}

					while (choosing)
					{
						int key = evmng_e.getLastKeyIfAvailable();

						if (key >= 0) choosing = false;

						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
							nowMult = multiply;
						}

						clearTo(al_map_rgb(0, 0, 0));
						bganim(multiply);
						drawIt(log, 0.0, -0.5, 0);
												
						drawIt(rec_back, 0.0, 0.1, 0);

						int tempcount = 0;
						for (auto& i : records) {
							al_draw_textf(font, al_map_rgb(255, 255, 255), 0.5*data.usedx, (0.46 + tempcount*0.038)*data.usedy, ALLEGRO_ALIGN_CENTER, "%s", i.c_str());
							tempcount++;
						}

						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f | TIMEMULTIPLY: %.3f", (float)nowFps, (float)nowMult);
						drawIt(vig, 0.0, 0.0, 0);
						flip();
						multiply = multiplier();
					}

					for (double pos = 0.02; pos < 1.55; pos += multiply * (0.2*fabsf(pos / 2.0)))
					{
						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
							nowMult = multiply;
						}

						clearTo(al_map_rgb(0, 0, 0));
						bganim(multiply);
						drawIt(log, (pos - 0.02)*0.8, -0.5, 0);
						
						drawIt(rec_back, pos - 0.02, 0.1, 0);

						int tempcount = 0;
						for (auto& i : records) {
							al_draw_textf(font, al_map_rgb(255, 255, 255), ((pos - 0.02)+1.0)*0.5*data.usedx, (0.46 + tempcount * 0.038)*data.usedy, ALLEGRO_ALIGN_CENTER, "%s", i.c_str());
							tempcount++;
						}

						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f | TIMEMULTIPLY: %.3f | POSRN: %.4f", (float)nowFps, (float)nowMult, pos);
						drawIt(vig, 0.0, 0.0, 0);
						flip();

						multiply = multiplier();
					}
					data.now = LSW_S_MENU;
				}
					break;
				case LSW_S_PLAY:

				{
					ALLEGRO_BITMAP *log, *vig, *opt_01, *opt_02, *opt_03;
					ALLEGRO_FONT *font;
					clock_t now = clock() - CLOCKS_PER_SEC / 4;
					double nowFps = 0.0, nowMult = multiply;
					int opt = 0;
					bool choosing = true;
					level = 0;

					log = data.data_control.get(LSW_BMP_LOGO);
					vig = data.data_control.get(LSW_BMP_VIGNETTE);
					opt_01 = data.data_control.get(LSW_BMP_MENU_OPT_01_S);
					opt_02 = data.data_control.get(LSW_BMP_MENU_OPT_02_S);
					opt_03 = data.data_control.get(LSW_BMP_MENU_OPT_03_S);
					font = data.data_control.get(LSW_FONT_DEJAVUSANS);

					multiplier(); // reset for animation
					multiply = 0.0;

					// pre-animation full of features because I CAN :3
					for (double pos = -1.55; pos < -0.02; pos += multiply * (0.2*fabsf(pos / 2.0)))
					{
						int key = evmng_e.getLastKeyIfAvailable();

						switch (key)
						{
						case ALLEGRO_KEY_UP:
							if (--opt < 0) opt = 2;
							break;
						case ALLEGRO_KEY_DOWN:
							if (++opt > 2) opt = 0;
							break;
						}

						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
							nowMult = multiply;
						}

						clearTo(al_map_rgb(0, 0, 0));
						bganim(multiply);
						drawIt(log, -(pos + 0.02), -0.5, 0);

						switch (opt)
						{
						case 0:
							drawIt(opt_01, pos + 0.02, 0.0, 0);
							break;
						case 1:
							drawIt(opt_02, pos + 0.02, 0.0, 0);
							break;
						case 2:
							drawIt(opt_03, pos + 0.02, 0.0, 0);
							break;
						default:
							opt = 0;
							break;
						}

						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f | TIMEMULTIPLY: %.3f | POSRN: %.4f", (float)nowFps, (float)nowMult, pos);
						drawIt(vig, 0.0, 0.0, 0);
						flip();

						multiply = multiplier();
					}

					while (choosing)
					{
						int key = evmng_e.getLastKeyIfAvailable();

						switch (key)
						{
						case ALLEGRO_KEY_UP:
							if (--opt < 0) opt = 2;
							break;
						case ALLEGRO_KEY_DOWN:
							if (++opt > 2) opt = 0;
							break;
						case ALLEGRO_KEY_ENTER:
							choosing = false;
							break;
						case ALLEGRO_KEY_1:
							opt = 0;
							choosing = false;
							break;
						case ALLEGRO_KEY_2:
							opt = 1;
							choosing = false;
							break;
						case ALLEGRO_KEY_3:
							opt = 2;
							choosing = false;
							break;
						case ALLEGRO_KEY_ESCAPE:
							data.now = LSW_S_MENU;
							choosing = false;
							break;
						}

						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
							nowMult = multiply;
						}
						clearTo(al_map_rgb(0, 0, 0));
						bganim(multiply);
						drawIt(log, 0.0, -0.5, 0);

						switch (opt)
						{
						case 0:
							drawIt(opt_01, 0.0, 0.0, 0);
							break;
						case 1:
							drawIt(opt_02, 0.0, 0.0, 0);
							break;
						case 2:
							drawIt(opt_03, 0.0, 0.0, 0);
							break;
						default:
							opt = 0;
							break;
						}

						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f | TIMEMULTIPLY: %.3f", (float)nowFps, (float)nowMult);
						drawIt(vig, 0.0, 0.0, 0);
						flip();
						multiply = multiplier();
					}

					for (double pos = 0.02; pos < 1.55; pos += multiply * (0.2*fabsf(pos / 2.0)))
					{
						clearTo(al_map_rgb(0, 0, 0));
						bganim(multiply);
						drawIt(log, -(pos - 0.02), -0.5, 0);

						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
							nowMult = multiply;
						}

						switch (opt)
						{
						case 0:
							drawIt(opt_01, pos - 0.02, 0.0, 0);
							break;
						case 1:
							drawIt(opt_02, pos - 0.02, 0.0, 0);
							break;
						case 2:
							drawIt(opt_03, pos - 0.02, 0.0, 0);
							break;
						default:
							opt = 0;
							break;
						}

						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f | TIMEMULTIPLY: %.3f | POSRN: %.4f", (float)nowFps, (float)nowMult, pos);
						drawIt(vig, 0.0, 0.0, 0);
						flip();

						multiply = multiplier();
					}

					if (data.now != LSW_S_MENU) {
						switch (opt) {
						case 0:
							level = 0;
							data.now = LSW_S_GAMING;
							break;
						case 1:
							level = 1;
							data.now = LSW_S_GAMING;
							break;
						case 2:
							level = 2;
							data.now = LSW_S_GAMING;
							break;
						}
					}
				}
					break;
				case LSW_S_EXIT:
					deinitAll();
					return true;
				case LSW_S_GAMING:
				{
					mapthing map;

					clearTo(al_map_rgb(0, 255, 255));
					flip();

					if (!map.generate(level)) {
						continue;
					}

					clearTo(al_map_rgb(0, 255, 0));
					flip();

					/*
					
		_things->images->apoio_01 = al_load_bitmap(datapath_background_01);
		_things->images->apoio_02 = al_load_bitmap(datapath_block);
		_things->images->apoio_03 = al_load_bitmap(datapath_menu_block);
		_things->images->apoio_04 = al_load_bitmap(datapath_person);
		_things->images->apoio_05 = al_load_bitmap(datapath_person_f01);
		_things->images->apoio_06 = al_load_bitmap(datapath_person_f02);
		_things->images->apoio_07 = al_load_bitmap(datapath_dark_01);
		_things->images->apoio_08 = al_load_bitmap(datapath_dark_02);
		_things->images->apoio_09 = al_load_bitmap(datapath_dark_03);
		_things->images->apoio_10 = al_load_bitmap(datapath_pause_continue);
		_things->images->apoio_11 = al_load_bitmap(datapath_pause_exit);
		_things->images->apoio_12 = al_load_bitmap(datapath_saving_score);
		_things->images->apoio_13 = al_load_bitmap(datapath_block_end);
		*/

					ALLEGRO_BITMAP *log, *vig, *drk[3], *plr[3], *bkg, *blk, *enb;
					ALLEGRO_FONT *font;
					clock_t now = clock() - CLOCKS_PER_SEC / 4;
					double nowFps = 0.0, nowMult = multiply;
					bool playin = true;
					bool paused = false;
					bool save_score = true;

					//double direct[2] = { 0.0 }; // +right/-left, +down/-up
					int way = -1; // NSWE
					double speed = 0.0;
					double posrel[2] = { 0.0 };
					double plrrot = 0.0;

					double playersiz_rel[2] = { 0.0 };
					double blocksize_rel[2] = { 0.0 };
					double y_offset = 0.0;

					double campos[2] = { 0.0 };

					log = data.data_control.get(LSW_BMP_LOGO);
					vig = data.data_control.get(LSW_BMP_VIGNETTE);
					bkg = data.data_control.get(LSW_BMP_BACKGROUND_01);
					blk = data.data_control.get(LSW_BMP_BLOCK);
					enb = data.data_control.get(LSW_BMP_SAVING_SCORE);
					for (int p = 0; p < 3; p++) drk[p] = data.data_control.get((images_available)(p + LSW_BMP_DARK_01));
					for (int p = 0; p < 3; p++) plr[p] = data.data_control.get((images_available)(p + LSW_BMP_PERSON));

					font = data.data_control.get(LSW_FONT_DEJAVUSANS);

					y_offset = (56.0 / al_get_bitmap_width(blk)) / base_res[1];
					playersiz_rel[0] = al_get_bitmap_width(plr[0]) * 1.0 / base_res[0];
					playersiz_rel[1] = al_get_bitmap_height(plr[0]) * 1.0 / base_res[1];
					blocksize_rel[0] = al_get_bitmap_width(blk) * 1.0 / base_res[0];
					blocksize_rel[1] = al_get_bitmap_height(blk) * 1.0 / base_res[1];
					multiplier(); // reset for animation
					multiply = 0.0;

					while (playin)
					{
						multiply = multiplier();

						if (clock() - now > CLOCKS_PER_SEC / 4) {
							now += CLOCKS_PER_SEC / 4;
							nowFps = lastFPS();
							nowMult = multiply;
						}

						clearTo(al_map_rgb(0, 25, 0));
						drawIt(bkg, 0.0, 0.0, 0);

						if (paused)
						{
							int got = pauseScreenGame();
							multiplier();
							if (got == 1) {
								playin = false;
								save_score = false;
								data.now = LSW_S_MENU;
							}
							else {
								paused = false;
							}
							continue;
						}

						int key = data.evm.getLastKeyIfAvailable(LSW_KEYPRESSED);
						int keykeep = data.evm.getLastKeyIfAvailable(LSW_KEYKEEP_LAST);

						switch (key)
						{
						case ALLEGRO_KEY_ESCAPE:
							paused = true;
							continue;
						}

						switch (keykeep)
						{
						case ALLEGRO_KEY_UP: case ALLEGRO_KEY_W:
							way = 0;
							break;
						case ALLEGRO_KEY_LEFT: case ALLEGRO_KEY_A:
							way = 2;
							break;
						case ALLEGRO_KEY_DOWN: case ALLEGRO_KEY_S:
							way = 1;
							break;
						case ALLEGRO_KEY_RIGHT: case ALLEGRO_KEY_D:
							way = 3;
							break;
						case -1:
							way = -1;
						}
						
						if (way >= 0)
							speed += 0.00005 + 0.003*speed;

						speed -= speed * 0.005;
						if (speed > 0.2) speed = 0.2;

						while (plrrot > 359.0)
							plrrot -= 360.0;
						while (plrrot < -1.0)
							plrrot += 360.0;

						switch (way)
						{
						case 0: // north
							if (plrrot < 180.0) plrrot -= ((plrrot) / 2.0)*0.3*multiply;
							else plrrot += ((360.0 - plrrot) / 6.0)*multiply;
							break;
						case 1: // south
							if (plrrot < 180.0) plrrot += ((180.0 - plrrot) / 2.0)*0.3*multiply;
							else plrrot -= ((plrrot - 180.0) / 6.0)*multiply;
							break;
						case 2: // east
							if (plrrot < 90.0) plrrot -= ((270.0 - plrrot) / 6.0)*0.3*multiply;
							else plrrot += ((270.0 - plrrot) / 6.0)*multiply;
							break;
						case 3: // west
							if (plrrot > 270.0) plrrot -= ((90.0 - plrrot) / 6.0)*0.3*multiply;
							else plrrot += ((90.0 - plrrot) / 6.0)*multiply;
							break;
						}

						double pi_r = ALLEGRO_PI * plrrot / 180.0;
						posrel[0] += multiply * speed * (sin(pi_r));
						posrel[1] += multiply * speed * (-cos(pi_r));

						if (posrel[0] - campos[0] > 1.0) posrel[0] = 1.0 + campos[0];
						if (posrel[0] - campos[0] < -1.0) posrel[0] = -1.0 + campos[0];
						if (posrel[1] - campos[1] > 1.0) posrel[1] = 1.0 + campos[1];
						if (posrel[1] - campos[1] < -1.0) posrel[1] = -1.0 + campos[1];

						// move cam
						double cammult[2] = { (posrel[0] - campos[0]) , (posrel[1] - campos[1]) };
						if (cammult[0] > 0.8)
						{
							campos[0] += (cammult[0] - 0.8) * 0.2 * multiply;
						}
						if (cammult[0] < -0.8)
						{
							campos[0] += (cammult[0] + 0.8) * 0.2 * multiply;
						}
						if (cammult[1] > 0.8)
						{
							campos[1] += (cammult[1] - 0.8) * 0.2 * multiply;
						}
						if (cammult[1] < -0.8)
						{
							campos[1] += (cammult[1] + 0.8) * 0.2 * multiply;
						}

						/*if (campos[0] < 0.0) campos[0] = 0.0;
						if (campos[1] < 0.0) campos[1] = 0.0;*/

						/*
						if (posrel[0]- campos[0] > 0.95)
							campos[0] += 0.001 + (0.3-(1.0 - posrel[0] - campos[0])) * multiply * speed * (sin(pi_r));
						else if (posrel[0]- campos[0] > 0.82)
							campos[0] += 0.001 + 0.2 * multiply * speed * (sin(pi_r));
						else if (posrel[0]- campos[0] > 0.7)
							campos[0] += 0.001 + 0.2 * multiply * speed * (sin(pi_r));
							*/

						// cam[t] == 1.0 -> moved 7.5 blocks (x)
						// cam[t] == 1.0 -> moved 4,21875 blocks (x)
						for (int py = (campos[1] * 4.21875) - 1; py < 9 + (campos[1] * 4.21875); py++)
						{
							for (int px = (campos[0] * 7.5) - 1; px < 15 + (campos[0] * 7.5); px++)
							{
								double xx, yy;
								xx = (px * (blocksize_rel[0]) - 0.5) * 2.0 - campos[0];
								yy = (py * (blocksize_rel[1]) - 0.5) * 2.0 /*+ y_offset*/ - campos[1];

								if (map.readpos(px, py) <= 0) drawIt(blk, xx, yy, 0.0, 1.0, 1.0, -1.0, 0.0, 0.0);
							}
						}
						
						drawIt(plr[((way >= 0) ? (1 + (int)(2.0*al_get_time()) % 2) : 0)], posrel[0] - campos[0], posrel[1] - campos[1], plrrot, 1.0, 1.0, 5.0);



						al_draw_textf(font, al_map_rgb(255, 255, 0), 1, 1, 0, "FPS: %.2f | TMULT: %.3f | PlrPos: %.3fx%.3f / %.3fx%.3f (relative); Speed: %.2f; Rot: %.2f | CPOS [%.2f;%.2f]", (float)nowFps, (float)nowMult, posrel[0], posrel[1], cammult[0], cammult[1], speed, plrrot, campos[0], campos[1]);

						drawIt(vig, 0.0, 0.0, 0);
						flip();
					}
				}
					break;
				}
			}
			return true;
		}
		
		void displayer::drawIt(ALLEGRO_BITMAP *chosen, const double pos_related_x, const double pos_related_y, const double rotation, const double scale_x, const double scale_y, const double hasboxthing, double pos_center_bitmap_x, double pos_center_bitmap_y)
		{
			if (!chosen) return;
			float _scale_x, _scale_y;
			_scale_x = (1.0f*data.usedx / base_res[0]) * scale_x;
			_scale_y = (1.0f*data.usedy / base_res[1]) * scale_y;
			int sx_b = al_get_bitmap_width(chosen);
			int sy_b = al_get_bitmap_height(chosen);
			if (pos_center_bitmap_x < 0.0 || pos_center_bitmap_y < 0.0)
			{
				pos_center_bitmap_x = (sx_b / 2.0);
				pos_center_bitmap_y = (sy_b / 2.0);
			}
			float var1, var2; // posx, posy
			var1 = data.usedx * ((pos_related_x + 1.0) / 2.0);
			var2 = data.usedy * ((pos_related_y + 1.0) / 2.0);

			al_draw_scaled_rotated_bitmap(chosen,
				pos_center_bitmap_x,
				pos_center_bitmap_y,
				var1,
				var2,
				_scale_x,
				_scale_y,
				(rotation / 180.0)*ALLEGRO_PI,
				0);
			if (hasboxthing > 0.0)
			{
				double box_x1 = var1 - pos_center_bitmap_x * _scale_x;
				double box_y1 = var2 - pos_center_bitmap_y * _scale_y;
				double box_x2 = var1 + pos_center_bitmap_x * _scale_x;
				double box_y2 = var2 + pos_center_bitmap_y * _scale_y;
				al_draw_rectangle(box_x1, box_y1, box_x2, box_y2, al_map_rgb(255, 0, 0), hasboxthing*sqrt(_scale_x*_scale_y));
			}
		}
		void displayer::bganim(const double mult)
		{
			double calc = (1.0 * data.usedx/base_res[0]);
			ALLEGRO_BITMAP *blk;
			blk = data.data_control.get(LSW_BMP_MENU_BLOCK);
			int blk_siz = calc * al_get_bitmap_width(blk);

			data.anim_posxy_keep += mult * 1.2;

			if (data.anim_posxy_keep >= blk_siz/2) data.anim_posxy_keep -= 1.0*blk_siz;
			for (double basex = data.anim_posxy_keep; basex < data.usedx + blk_siz / 2; basex += blk_siz)
			{
				for (double basey = data.anim_posxy_keep; basey < data.usedy + blk_siz / 2; basey += blk_siz)
				{
					drawIt(blk, (2.0*basex/ data.usedx)-1.0, (2.0*basey/ data.usedy)-1.0, 0.0);
				}
			}
		}
		const int displayer::pauseScreenGame() // 0 == continue, 1 == exit
		{
			ALLEGRO_BITMAP *pause_anim[30] = { nullptr };
			ALLEGRO_BITMAP *vig;
			ALLEGRO_BITMAP *options[2];

			vig = data.data_control.get(LSW_BMP_VIGNETTE);
			for (int p = 0; p < 30; p++) pause_anim[p] = data.data_control.get((images_available)(p + LSW_BMP_PAUSE_00));
			for (int p = 0; p < 2; p++) options[p] = data.data_control.get((images_available)(p + LSW_BMP_PAUSE_CONTINUE));

			double val_precise = 0.0;
			bool choosing = true;
			int opt = 0;

			while (choosing)
			{
				val_precise += multiplier()*0.5;

				int key = data.evm.getLastKeyIfAvailable();

				switch (key)
				{
				case ALLEGRO_KEY_UP:
					if (++opt > 1) opt = 0;
					break;
				case ALLEGRO_KEY_DOWN:
					if (--opt < 0) opt = 1;
					break;
				case ALLEGRO_KEY_ENTER:
					choosing = false;
					continue;
				case ALLEGRO_KEY_ESCAPE:
					opt = 0;
					choosing = false;
					continue;
				}
				
				clearTo(al_map_rgb(0, 0, 0));

				if ((int)val_precise >= 30) val_precise = 0.0;
				
				drawIt(pause_anim[(int)val_precise], 0.0, -0.5, 0);
				drawIt(options[(opt > 1) ? 1 : opt], 0.0, 0.0, 0);

				drawIt(vig, 0.0, 0.0, 0);
				flip();
			}
			return opt;
		}
		const bool displayer::init()
		{
			if (data.loaded) return true;
			data.muu.lock();

			al_get_display_mode(al_get_num_display_modes() - 1, &data.full);

			al_set_new_display_option(ALLEGRO_AUTO_CONVERT_BITMAPS, 1, ALLEGRO_DONTCARE);
			al_set_new_display_flags(ALLEGRO_FRAMELESS | ALLEGRO_OPENGL | ALLEGRO_OPENGL_3_0);
			al_set_new_display_option(ALLEGRO_VSYNC, 2, ALLEGRO_SUGGEST);

			data.display = al_create_display(data.full.width, data.full.height);
			if (!data.display) {
				data.muu.unlock();
				throw "FAILED CREATING DISPLAY!";
				return false;
			}
			
			al_set_new_bitmap_flags(ALLEGRO_CONVERT_BITMAP);

			data.usedx = data.full.width;
			data.usedy = data.full.height;
			float temp_f = 1.0*data.usedy / data.usedx;
			if (temp_f > (16.0 / 9)) {
				data.usedx = data.usedy * 16.0 / 9;
			}
			else {
				data.usedy = data.usedx * 9.0 / 16;
			}

			data.buffer = al_create_bitmap(data.usedx, data.usedy);
			if (!data.buffer) {
				al_destroy_display(data.display);
				data.muu.unlock();
				throw "FAILED CREATING DISPLAY!";
				return false;
			}

			if (data.data_control.load(LSW_BMP_ICON)) al_set_display_icon(data.display, data.data_control.get(LSW_BMP_ICON));

			data.prop = data.usedx / base_res[0];

			float temp_siz_font = 1.0*sqrt(data.usedx*data.usedy)*28.8/sqrt(base_res[0]*base_res[1]);
			if (!data.data_control.load(LSW_FONT_DEJAVUSANS, temp_siz_font))
			{
				al_destroy_display(data.display);
				al_destroy_bitmap(data.buffer);
				data.data_control.unloadAll();
				data.data_control.clearAll();
				data.muu.unlock();
				throw "FAILED LOADING FONT!";
				return false;
			}

			data.ev_qu = al_create_event_queue();
			if (!data.ev_qu) {
				al_destroy_display(data.display);
				al_destroy_bitmap(data.buffer);
				data.data_control.unloadAll();
				data.data_control.unload(LSW_FONT_DEJAVUSANS);
				data.data_control.clearAll();
				data.muu.unlock();
				throw "FAILED CREATING QUEUE!";
				return false;
			}

			al_register_event_source(data.ev_qu, al_get_display_event_source(data.display));
			al_register_event_source(data.ev_qu, al_get_keyboard_event_source());

			al_set_window_title(data.display, "Maze Game by Erfra REVAMPED");
			al_set_exe_name("Maze_App.exe");

			if (!data.evm.init(data.ev_qu)) {
				data.data_control.unloadAll();
				data.data_control.unload(LSW_FONT_DEJAVUSANS);
				al_destroy_event_queue(data.ev_qu);
				al_destroy_bitmap(data.buffer);
				data.data_control.clearAll();
				al_destroy_display(data.display);
				data.muu.unlock();
				throw "FAILED CREATING KEYBOARD THREAD!";
				return false;
			}
			data.lastC = GetTickCount64();

			al_set_target_bitmap(data.buffer);
			data.loaded = true;
			data.muu.unlock();
			return true;
		}
		void displayer::clearTo(const ALLEGRO_COLOR c)
		{
			al_clear_to_color(c);
		}
		const double displayer::multiplier()
		{
			double saved = al_get_time();
			double val = saved - data.lastC_fMult_al;
			data.lastC_fMult_al = saved;
			return val * 60.0; // 1.0 multiplier for 60 fps

		}
		void displayer::flip()
		{
			al_set_target_backbuffer(data.display);
			al_draw_scaled_bitmap(data.buffer, 0, 0, data.usedx, data.usedy, 0, 0, al_get_display_width(data.display), al_get_display_height(data.display), 0);
			al_flip_display();
			al_set_target_bitmap(data.buffer);
			data.tickCount = GetTickCount64() - data.lastC;

			if (data.lastdraw != 0.0) {
				double noww = al_get_time();
				data.fps = (data.fps * 2 + (1.0 / (noww - data.lastdraw)))/3;
				data.lastdraw = noww;
			}
			else data.lastdraw = al_get_time();

			if (!data.evm.keepdisplayOn()) {
				deinitAll();
				exit(0);
			}
		}
		const double displayer::lastFPS()
		{
			return data.fps;
		}
		void displayer::fixLoad()
		{
			al_set_target_backbuffer(data.display);
			al_set_new_bitmap_flags(ALLEGRO_VIDEO_BITMAP);
			al_set_target_bitmap(data.buffer);
		}
		void displayer::deinitAll()
		{
			if (!data.loaded) return;
			data.muu.lock();

			data.evm.deinit();
			data.data_control.unloadAll();
			data.data_control.unload(LSW_FONT_DEJAVUSANS);
			al_destroy_event_queue(data.ev_qu);
			al_destroy_bitmap(data.buffer);
			data.data_control.clearAll();
			al_destroy_display(data.display);

			data.loaded = false;
			data.muu.unlock();
		}


		const bool event_mng::init(ALLEGRO_EVENT_QUEUE* gimme)
		{
			if (!gimme) return false;
			if (data.keeprunning) return false;

			data.ev_qu = gimme;
			data.thr = new std::thread(_thr_keyboard, &data);
			if (data.thr) for (int timing = 0; timing < 20 && (!data.keeprunning); timing++) Sleep(50);
			else return false;
			if (!data.keeprunning) return false;

			return true;
		}
		void event_mng::deinit()
		{
			if (!data.keeprunning) return;

			data.keeprunning = false;
			data.thr->join();
		}
		const bool event_mng::keepdisplayOn()
		{
			return !data.closewindow;
		}
		const int event_mng::getLastKeyIfAvailable(const key_type which)
		{
			if (which == LSW_KEYPRESSED) {
				if (data.hasnewstroke)
				{
					int v = data.laststroke;
					data.hasnewstroke = false;
					return v;
				}
				return -1;
			}
			else if (which == LSW_KEYLEFT) {
				if (data.hasnewstrokeleft)
				{
					int v = data.laststrokeleft;
					data.hasnewstrokeleft = false;
					return v;
				}
				return -1;
			}
			else if (which == LSW_KEYKEEP_LAST)
			{
				return data.lastkeykeep;
			}
			return -1;
		}

		void _thr_temp_loadallresources(int* which, bool* hasdone)
		{
			if (!hasdone || !which) return;

			controller ctrl;
			//displayer disp;

			*hasdone = false;

			//disp.fixLoad();
			for (*which = 0; *which < LSW_BMP_MAX; (*which)++) ctrl.load((images_available)(*which));

			*hasdone = true;
		}

		void _thr_keyboard(event_mng_data* dat)
		{
			if (!dat) return;
			dat->keeprunning = true;

			while (dat->keeprunning)
			{
				al_wait_for_event(dat->ev_qu, &dat->ev);

				if (dat->ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
				{
					dat->closewindow = true;
					dat->keeprunning = false;
					continue;
				}
				if (dat->ev.type == ALLEGRO_EVENT_KEY_DOWN)
				{
					for (unsigned tried = 0; (tried < 10) && dat->hasnewstroke; tried++) Sleep(10);
					dat->laststroke = dat->ev.keyboard.keycode;
					dat->lastkeykeep = dat->ev.keyboard.keycode;
					dat->hasnewstroke = true;
				}
				if (dat->ev.type == ALLEGRO_EVENT_KEY_UP)
				{
					for (unsigned tried = 0; (tried < 10) && dat->hasnewstrokeleft; tried++) Sleep(10);
					dat->laststrokeleft = dat->ev.keyboard.keycode;
					if (dat->laststrokeleft == dat->lastkeykeep) dat->lastkeykeep = -1;
					dat->hasnewstrokeleft = true;
				}
				if (dat->ev.type == ALLEGRO_EVENT_KEY_CHAR)
				{
					dat->lastkeykeep = dat->ev.keyboard.keycode;
				}
			}
		}
	}
}