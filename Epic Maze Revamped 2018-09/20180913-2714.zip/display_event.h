#pragma once

#include <allegro5/allegro5.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>
#include <vector>
#include <mutex>
#include <string>
#include <Windows.h>

#include "resource.h"

#define VERSION "V2.2A snapshot-6"


// prop == 1 + 7/9

namespace LSW {

	namespace EpicMazeR {

		const int base_res[2] = { 1920,1080 };

		enum stats {
			LSW_S_INITIALIZING,
			LSW_S_MENU,
			LSW_S_INSTR,
			LSW_S_RECORDS,
			LSW_S_PLAY,
			LSW_S_EXIT,
			LSW_S_GAMING
		};

		enum key_type {
			LSW_KEYPRESSED,
			LSW_KEYLEFT,
			LSW_KEYKEEP_LAST
		};

		struct scores {
			std::string name;
			double score = -1.0;
		};

		struct event_mng_data {
			ALLEGRO_EVENT_QUEUE* ev_qu = nullptr;
			ALLEGRO_EVENT ev;

			std::thread* thr = nullptr;

			// LSW_KEYPRESSED
			int laststroke = 0;
			bool hasnewstroke = false;
			// LSW_KEYLEFT
			int laststrokeleft = 0;
			bool hasnewstrokeleft = false;

			int lastkeykeep = -1;


			bool closewindow = false;

			bool keeprunning = false;
			std::mutex m;
		};

		class event_mng {
			static event_mng_data data;
		public:
			const bool init(ALLEGRO_EVENT_QUEUE*);
			void deinit();

			const bool keepdisplayOn();
			const int getLastKeyIfAvailable(const key_type = LSW_KEYPRESSED);
		};

		// ********************************** //


		struct gameplay_needs {
			bool being_made = true;
			int needed_reset = 0;
			int debug = 0;

			mapthing* map = nullptr;
			infinity_map* map2 = nullptr;

			std::thread* collision_controller = nullptr;
			int istestingcollision = -1;
			int main_asks_for_pause = 0;
			double collision_tps = 0.0;

			clock_t now = 0;
			double nowFps = 0.0, nowMult = 0.0;
			bool playin = true;
			bool paused = false;
			bool save_score = true;
			bool asked_for_help = false;

			int way = -1; // NSWE
			bool alternative_way[4] = { false };
			int way_cam = -1;
			double speed = 0.0;
			double speed_y = 0.0;
			double distance_taken = 0.0;
			double posrel[2] = { -0.9, -0.9 };
			double plrrot = 0.0;

			double playersiz_rel[2] = { 0.0, 0.0 };
			double blocksize_rel[2] = { 0.0, 0.0 };
			//double y_offset = 0.0;
			bool colided = false;
			double cases_times_mult = 0.0;

			double time_final[2] = { 0.0 };
			double final_score = 0.0;

			double min_dist[9][2];
			bool min_dist_used[9] = { false };
			double fixed_distance = 1.0;

			double campos[2] = { 0.0, 0.0 };
			double cammult[2];
			
			int key = -1, keykeep = -1, keylost = -1;
		};

		struct displayer_data {
			ALLEGRO_DISPLAY* display = nullptr;
			ALLEGRO_BITMAP* buffer = nullptr;
			ALLEGRO_COLOR color_blend = al_map_rgba_f(1.0, 1.0, 1.0, 1.0);
			ALLEGRO_BITMAP* transparency = nullptr;
			ALLEGRO_DISPLAY_MODE full;
			ALLEGRO_EVENT_QUEUE* ev_qu = nullptr;
			controller data_control;
			gameplay_needs *if_playin = nullptr;
			int usedx = 0, usedy = 0;
			float prop = 0.0;

			bool loaded = false;
			std::mutex muu;

			event_mng evm;

			double fps = 0.0;
			ULONGLONG tickCount = 0;
			stats now = LSW_S_INITIALIZING;

			ULONGLONG lastC = 0; // don't use normally
			double lastC_fMult_al = 0.0; // don't use normally

			double anim_posxy_keep = 0.0; // internal
			double lastdraw = 0.0; // internal

			double fixed_fps = -1;
			int display_mode_draw = false;

			bool infinite_mode = false;
		};

		enum assistance_nsew {
			LSW_P_NORTH,
			LSW_P_SOUTH,
			LSW_P_EAST,
			LSW_P_WEST
		};


		class displayer {
			static displayer_data data;

			int level = 0;
			bool enabled_alternative_mode = false;
			bool infinite_map = false;
			bool isFullscreen = true;

			// bmp, x, y, rot (�), scalex, scaley, boxsiz, cx, cy, blending? (only if no border)
			void drawIt(ALLEGRO_BITMAP*, const double, const double, const double, const double = 1.0, const double = 1.0, const double = -1, double = -1, double = -1, const ALLEGRO_COLOR = al_map_rgb(255, 0, 0), const bool = false);
			void bganim(const double); // you have to call multiplier to work (or its val)! (multiplier == sets right speed!)
			const int pauseScreenGame();

			// x, y, scale, blur
			void drawCircle(const double, const double, const double);

			// dx & dy. (plr pos - block pos)
			const assistance_nsew _whereToTp(const double, const double);
			// degrees
			const double _ang_dif(const double, const double);
			void fixFPS(const double, const double, const double);

		public:
			void _thr_collision_work(gameplay_needs&);
			const bool init();

			void clearTo(const ALLEGRO_COLOR);
			const double multiplier();
			void flip();
			const double lastFPS();
			void fixLoad();

			void resizeBufTo(const int, const int);

			const int think();

			void deinitAll();
		};

		void _thr_collisionwork_ext(gameplay_needs*, displayer*);
		void _thr_temp_generatemap(mapthing*, int, int*, bool*, bool*);
		void _thr_temp_loadallresources(int*, bool*);
		void _thr_keyboard(event_mng_data*);

		const char translate_al(const int);
	}
}